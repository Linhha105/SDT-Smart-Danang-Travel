
const db = require("./db");

async function testDatabase() {
  try {
    const result = await db.query(
      "SELECT current_database() AS database_name"
    );

    console.log("KET NOI POSTGRESQL THANH CONG!");
    console.log("Database:", result.rows[0].database_name);

  } catch (error) {
    console.error(
      "LOI KET NOI DATABASE:",
      error.message
    );
    process.exitCode = 1;

  } finally {
    await db.end();
  }
}

testDatabase();
