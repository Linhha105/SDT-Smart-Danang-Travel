const cookieParser = require("cookie-parser");
const authRoutes = require("./routes/auth");
const express = require("express");
const onboardingRoutes = require("./routes/onboarding");

const app = express();
console.log("DANG CHAY FILE:", __filename);
const PORT = 3010;

app.use(express.json());
app.use(cookieParser());

// API kiểm tra backend
app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    message: "Backend DanangGo đang hoạt động",
  });
});

// Kết nối router onboarding
console.log("Kieu onboardingRoutes:", typeof onboardingRoutes);
app.use("/api/onboarding", onboardingRoutes);
app.use("/api/auth", authRoutes);

const path = require("path");

app.use(express.static(
  path.join(__dirname, "../../Frontend")
));

app.get("/api/debug-version", (req, res) => {
  res.json({
    success: true,
    message: "DANANGGO AUTH DEBUG V3",
    serverFile: __filename,
    authRouterLoaded: typeof authRoutes,
    processId: process.pid
  });
});

app.post("/api/debug-auth", (req, res) => {
  res.json({
    success: true,
    message: "POST DEBUG OK",
    data: req.body
  });
});

// Khởi động server
app.listen(PORT, () => {
  console.log(`Server đang chạy tại http://localhost:${PORT}`);
});
