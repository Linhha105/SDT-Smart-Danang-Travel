const { z } = require("zod");
const express = require("express");

const router = express.Router();

// API GET kiểm tra
router.get("/options", (req, res) => {
  res.json({
    success: true,
    message: "GET onboarding hoạt động",
  });
});

const onboardingSchema = z.object({
  gender: z.enum(["Nam", "Nữ", "Khác"]),

  age: z.enum([
    "18 - 24 tuổi",
    "25 - 34 tuổi",
    "35 - 50 tuổi",
    "Trên 50 tuổi",
  ]),

  companion: z.enum([
    "Một mình",
    "Cặp đôi",
    "Bạn bè",
    "Gia đình",
  ]),

  interests: z.array(
    z.enum([
      "Biển & Nghỉ dưỡng",
      "Ẩm thực địa phương",
      "Check-in cảnh đẹp",
      "Trải nghiệm đêm",
      "Văn hóa & Lịch sử",
      "Cà phê & Chill",
    ])
  ).min(1, "Phải chọn ít nhất một sở thích"),

  budget: z.enum([
    "Tiết kiệm",
    "Tiêu chuẩn",
    "Thoải mái",
    "Nghỉ dưỡng cao cấp",
  ]),

  timeSlot: z.enum([
    "Sáng sớm (05:00 - 07:30)",
    "Sáng mát (08:00 - 11:00)",
    "Chiều hoàng hôn (15:30 - 18:30)",
    "Buổi tối sôi động (19:00 - 22:30)",
  ]),
});


function analyzeTravelStyle(preferences) {
  const interests = preferences.interests;

  if (interests.includes("Biển & Nghỉ dưỡng")) {
    return "Du Lịch Trải Nghiệm & Thư Giãn";
  }

  if (interests.includes("Văn hóa & Lịch sử")) {
    return "Du Lịch Văn Hóa & Khám Phá";
  }

  if (interests.includes("Ẩm thực địa phương")) {
    return "Du Lịch Ẩm Thực";
  }

  return "Du Lịch Khám Phá Đà Nẵng";
}

// API POST phân tích hồ sơ onboarding
router.post("/", (req, res) => {
  console.log("POST ONBOARDING VERSION 2");

  const result = onboardingSchema.safeParse(req.body);

  // Kiểm tra dữ liệu bằng Zod
  if (!result.success) {
    return res.status(400).json({
      success: false,
      message: "Dữ liệu onboarding không hợp lệ",
      errors: result.error.issues,
    });
  }

  const preferences = result.data;

  // Phân tích phong cách du lịch
  const travelStyle = analyzeTravelStyle(preferences);

  return res.status(200).json({
    success: true,
    message: "Phân tích hồ sơ thành công",
    version: 2,
    data: {
      preferences,
      travelStyle,
    },
  });
});
module.exports = router;
