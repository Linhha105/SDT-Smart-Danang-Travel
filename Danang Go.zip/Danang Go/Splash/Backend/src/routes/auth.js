
const express = require("express");
const argon2 = require("argon2");
const { z } = require("zod");
const { randomBytes, createHash } = require("node:crypto");
const { rateLimit } = require("express-rate-limit");
const db = require("../db");

const router = express.Router();

const COOKIE_NAME = "dananggo_session";
const SESSION_DAYS = 7;

const cookieOptions = {
  httpOnly: true,
  sameSite: "lax",
  secure: process.env.NODE_ENV === "production",
  path: "/",
};

// Hash session token
function hashToken(token) {
  return createHash("sha256")
    .update(token)
    .digest("hex");
}

// Giới hạn số lần đăng ký/đăng nhập
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: {
    success: false,
    message: "Quá nhiều yêu cầu. Vui lòng thử lại sau.",
  },
});

// Schema đăng ký
const registerSchema = z.object({
  fullName: z.string().trim().min(2).max(150),
  email: z.email().max(255),
  password: z.string().min(8).max(128),
});

// Schema đăng nhập
const loginSchema = z.object({
  email: z.email(),
  password: z.string().min(1),
});

// Tạo session đăng nhập
async function createLoginSession(userId, res) {
  const token = randomBytes(32).toString("hex");

  const expiresAt = new Date(
    Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000
  );

  await db.query(
    `INSERT INTO sessions
      (user_id, token_hash, expires_at)
     VALUES ($1, $2, $3)`,
    [userId, hashToken(token), expiresAt]
  );

  res.cookie(COOKIE_NAME, token, {
    ...cookieOptions,
    expires: expiresAt,
  });
}

// Lấy người dùng từ session
async function getCurrentUser(req) {
  const token = req.cookies?.[COOKIE_NAME];

  if (typeof token !== "string" || !token) {
    return null;
  }

  const result = await db.query(
    `SELECT u.id, u.full_name, u.email
     FROM sessions s
     JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = $1
       AND s.expires_at > NOW()`,
    [hashToken(token)]
  );

  return result.rows[0] || null;
}

// ===================================
// 1. API ĐĂNG KÝ TÀI KHOẢN
// POST /api/auth/register
// ===================================

router.post("/register", authLimiter, async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);

  if (!parsed.success) {
    return res.status(400).json({
      success: false,
      message: "Thông tin đăng ký không hợp lệ",
      errors: parsed.error.issues,
    });
  }

  const { fullName, password } = parsed.data;
  const email = parsed.data.email.trim().toLowerCase();

  try {
    // Mã hóa một chiều mật khẩu
    const passwordHash = await argon2.hash(password);

    // Lưu tài khoản vào PostgreSQL
    const result = await db.query(
      `INSERT INTO users
        (full_name, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, full_name, email, created_at`,
      [fullName, email, passwordHash]
    );

    const user = result.rows[0];

    // Tự đăng nhập sau khi đăng ký
    await createLoginSession(user.id, res);

    return res.status(201).json({
      success: true,
      message: "Đăng ký tài khoản thành công",
      user,
    });

  } catch (error) {
    if (error.code === "23505") {
      return res.status(409).json({
        success: false,
        message: "Email này đã được đăng ký",
      });
    }

    console.error("Register error:", error);

    return res.status(500).json({
      success: false,
      message: "Không thể đăng ký tài khoản",
    });
  }
});

// ===================================
// 2. API ĐĂNG NHẬP
// POST /api/auth/login
// ===================================

router.post("/login", authLimiter, async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);

  if (!parsed.success) {
    return res.status(400).json({
      success: false,
      message: "Email hoặc mật khẩu không hợp lệ",
    });
  }

  const email = parsed.data.email.trim().toLowerCase();
  const { password } = parsed.data;

  try {
    const result = await db.query(
      `SELECT id, full_name, email, password_hash
       FROM users
       WHERE email = $1`,
      [email]
    );

    const user = result.rows[0];

    // Xác minh mật khẩu
    if (
      !user ||
      !(await argon2.verify(user.password_hash, password))
    ) {
      return res.status(401).json({
        success: false,
        message: "Email hoặc mật khẩu không đúng",
      });
    }

    // Tạo phiên đăng nhập
    await createLoginSession(user.id, res);

    return res.status(200).json({
      success: true,
      message: "Đăng nhập thành công",
      user: {
        id: user.id,
        full_name: user.full_name,
        email: user.email,
      },
    });

  } catch (error) {
    console.error("Login error:", error);

    return res.status(500).json({
      success: false,
      message: "Không thể đăng nhập",
    });
  }
});

// ===================================
// 3. KIỂM TRA TÀI KHOẢN ĐĂNG NHẬP
// GET /api/auth/me
// ===================================

router.get("/me", async (req, res) => {
  try {
    const user = await getCurrentUser(req);

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Bạn chưa đăng nhập",
      });
    }

    return res.json({
      success: true,
      user,
    });

  } catch (error) {
    console.error("Session error:", error);

    return res.status(500).json({
      success: false,
      message: "Không thể kiểm tra tài khoản",
    });
  }
});

// ===================================
// 4. API ĐĂNG XUẤT
// POST /api/auth/logout
// ===================================

router.post("/logout", async (req, res) => {
  try {
    const token = req.cookies?.[COOKIE_NAME];

    if (typeof token === "string" && token) {
      await db.query(
        "DELETE FROM sessions WHERE token_hash = $1",
        [hashToken(token)]
      );
    }

    res.clearCookie(COOKIE_NAME, cookieOptions);

    return res.json({
      success: true,
      message: "Đăng xuất thành công",
    });

  } catch (error) {
    console.error("Logout error:", error);

    return res.status(500).json({
      success: false,
      message: "Không thể đăng xuất",
    });
  }
});

module.exports = router;
